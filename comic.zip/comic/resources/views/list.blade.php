@extends('layouts.base')
@section('css')
<link rel="stylesheet" href="{{ asset('/css/list.css')}}">
@endsection

@section('title', 'Livres')

@section('content')
<h1 class="title">Liste des personnages</h1>

<div class="list">
    <table class="table table-striped table-dark">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nom</th>
                <th scope="col">Dessinateur</th>
                <th scope="col">BD  </th>
            </tr>
        </thead>
        <tbody>
        @foreach ($characters as $character)
            <tr>
                <th scope="row">{{ $character->id }}</th>
                <td><a href="/character/{{ $character->id }}">{{ $character->name }}</a></td>
                <td><a href="/designer/{{ $character->designer->id }}">{{ $character->designer->name }}</a></td>
                <td>
                    @foreach ($character->comics as $comic)
                        <p>{{ $comic->name }}</p>
                    @endforeach
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
@endsection
