@extends('layouts.base')
@section('title', 'MAJ')
@section('css')
    <link rel="stylesheet" href="{{ asset('/css/update.css') }}">
@endsection

@section('content')
    <h1 class="title">Mettre à jour {{ $designer->name }} </h1>
    <div>
        <form action="/updateDesigner" method="POST">
            @csrf
            <input type="hidden" name="id" value="{{ $designer->id }}">
            <div class="form-group row">
                <label for="title" class="col-sm-4 col-form-label">Nom</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="name" placeholder="name" value="{{ $designer->name }}">
                </div>
            </div>
            <div class="form-group row">
                <label for="birth_year" class="col-sm-4 col-form-label">Année de naissance</label>
                <div class="col-sm-8">
                    <input type="number" class="form-control" name="birth_year" placeholder="Année de naissance" value="{{ $designer->birth_year }}">
                </div>
            </div>
            <div class="form-group row">
                <label for="nationality" class="col-sm-4 col-form-label">Nationalité</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="nationality" placeholder="Nationalité" value="{{ $designer->nationality }}">
                </div>
            </div>

                <button type="submit" class="btn btn-primary">Mettre à jour</button>
            </div>
        </form>
    </div>
@endsection
