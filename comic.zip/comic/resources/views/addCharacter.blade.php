@extends('layouts.base')
@section('title', 'Ajout')
@section('css')
    <link rel="stylesheet" href="{{ asset('/css/add.css') }}">
@endsection

@section('content')
    <h1 class="title">Ajoute un personnage !</h1>
    <div>
        <form action="/addCharacter" method="POST">
            @csrf
            <div class="form-group row">
                <label for="title" class="col-sm-4 col-form-label">Nom</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="name" placeholder="Nom" value="Tintin">
                </div>
            </div>
            <div class="form-group row">
                <label for="designer" class="col-sm-4 col-form-label">Dessinateur</label>
                <div class="col-sm-8">
                    <select name="designer_id" id="">
                        @foreach ($designers as $designer)
                        <option value="{{ $designer->id }}">{{ $designer->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label for="publication_year" class="col-sm-4 col-form-label">Année de création</label>
                <div class="col-sm-8">
                    <input type="number" class="form-control" name="creation_year" placeholder="Année de création" value="1929">
                </div>
            </div>
            <div class="form-group row">
                <label for="comic" class="col-sm-4 col-form-label">Bande dessinée</label>
                <div class="col-sm-8">
                    @foreach ($comics as $comic)
                        <input type="checkbox" name="comics" value="{{ $comic->id }}">
                        <label for="">{{ $comic->name }}</label>
                    @endforeach
                </div>
            </div>
            <div>
                <button type="submit" class="btn btn-primary">Ajouter</button>
            </div>
        </form>
    </div>
@endsection
