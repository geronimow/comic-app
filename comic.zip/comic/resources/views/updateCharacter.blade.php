@extends('layouts.base')
@section('title', 'MAJ')
@section('css')
    <link rel="stylesheet" href="{{ asset('/css/update.css') }}">
@endsection

@section('content')
    <h1 class="title">Mettre à jour {{ $character->name }} </h1>
    <div>
        <form action="/updateCharacter" method="POST">
            @csrf
            <input type="hidden" name="id" value="{{ $character->id }}">
            <div class="form-group row">
                <label for="title" class="col-sm-4 col-form-label">Nom</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="name" placeholder="name" value="{{ $character->name }}">
                </div>
            </div>
            <div class="form-group row">
                <label for="designer" class="col-sm-4 col-form-label">Dessinateur</label>
                <div class="col-sm-8">
                    <select name="designer_id" id="">
                        @foreach ($designers as $designer)
                        <option value="{{ $designer->id }}">{{ $designer->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label for="creation_year" class="col-sm-4 col-form-label">Année de création</label>
                <div class="col-sm-8">
                    <input type="number" class="form-control" name="creation_year" placeholder="Année de création" value="{{ $character->creation_year }}">
                </div>
            </div>
            <div class="form-group row">
                <label for="comic" class="col-sm-4 col-form-label">Bande dessinée</label>
                <div class="col-sm-8">
                    <select name="comics" id="">
                        @foreach ($comics as $comic)
                        <option value="{{ $comic->id }}">{{ $comic->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div>
                <button type="submit" class="btn btn-primary">Mettre à jour</button>
            </div>
        </form>
    </div>
@endsection
