
@extends('layouts.base')
@section('title', 'Livre')
@section('css')
    <link rel="stylesheet" href="{{ asset('/css/character.css') }}">
@endsection

@section('content')
    <h1 class="title">Détail du dessinateur</h1>
    <div id="card">
        <div class="card border-dark mb-3" style="max-width: 18rem;">
            <div class="card-header">{{ $designer->name }}</div>
            <div class="card-body text-dark flex">
                <p>Nationalité :</p>
                <p class="card-text">{{ $designer->nationality }}</p>
            </div>
            <div class="card-body text-dark flex">
                <p>Date de naissance :</p>
                <p class="card-text">{{ $designer->birth_year }}</p>
            </div>
            <div class="card-body text-dark flex">
              <form action="/deleteDesigner" method="POST">
                  @csrf
                  <input type="hidden" name="id" value="{{ $designer->id }}">
                  <input type="submit" class="btn btn-danger" value="Supprimer">
              </form>
            </div>
            <div class="card-body text-dark flex">
            <a href="/updateDesigner/{{ $designer->id }}" class="btn btn-success">Mettre à jour</a>
          </div>
        </div>
    </div>
@endsection
