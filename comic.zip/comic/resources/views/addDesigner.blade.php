@extends('layouts.base')
@section('title', 'Ajout')
@section('css')
    <link rel="stylesheet" href="{{ asset('/css/add.css') }}">
@endsection

@section('content')
    <h1 class="title">Ajoute un dessinateur !</h1>
    <div>
        <form action="/addDesigner" method="POST">
            @csrf
            <div class="form-group row">
                <label for="title" class="col-sm-4 col-form-label">Nom</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="name" placeholder="Nom" value="Hergé">
                </div>
            </div>

            <div class="form-group row">
                <label for="title" class="col-sm-4 col-form-label">Nationalité</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="nationality" placeholder="Nationalité" value="Belgique">
                </div>
            </div>

            <div class="form-group row">
                <label for="publication_year" class="col-sm-4 col-form-label">Année de naissance</label>
                <div class="col-sm-8">
                    <input type="number" class="form-control" name="birth_year" placeholder="Année de naissance" value="1907">
                </div>
            </div>
            <div>
                <button type="submit" class="btn btn-primary">Ajouter</button>
            </div>
        </form>
    </div>
@endsection
