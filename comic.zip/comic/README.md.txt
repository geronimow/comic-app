Mettre en place la base de donnés dans le fichier .env : DB_DATABASE.
Pour mettre en place les seeders, se rendre dans l'invite de commande et taper : php artisan migrate --seed.
