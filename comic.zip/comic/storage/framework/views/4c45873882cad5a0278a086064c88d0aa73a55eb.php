
<?php $__env->startSection('title', 'MAJ'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/update.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="title">Mettre à jour <?php echo e($character->name); ?> </h1>
    <div>
        <form action="/updateCharacter" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($character->id); ?>">
            <div class="form-group row">
                <label for="title" class="col-sm-4 col-form-label">Nom</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="name" placeholder="name" value="<?php echo e($character->name); ?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="designer" class="col-sm-4 col-form-label">Dessinateur</label>
                <div class="col-sm-8">
                    <select name="designer_id" id="">
                        <?php $__currentLoopData = $designers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($designer->id); ?>"><?php echo e($designer->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label for="creation_year" class="col-sm-4 col-form-label">Année de création</label>
                <div class="col-sm-8">
                    <input type="number" class="form-control" name="creation_year" placeholder="Année de création" value="<?php echo e($character->creation_year); ?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="comic" class="col-sm-4 col-form-label">Bande dessinée</label>
                <div class="col-sm-8">
                    <select name="comics" id="">
                        <?php $__currentLoopData = $comics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($comic->id); ?>"><?php echo e($comic->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div>
                <button type="submit" class="btn btn-primary">Mettre à jour</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\comic\resources\views/updateCharacter.blade.php ENDPATH**/ ?>