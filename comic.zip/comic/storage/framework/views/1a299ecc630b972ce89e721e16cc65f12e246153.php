

<?php $__env->startSection('title', 'Livre'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/character.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="title">Détail du personnage</h1>
    <div id="card">
        <div class="card border-dark mb-3" style="max-width: 18rem;">
            <div class="card-header"><?php echo e($character->name); ?></div>
            <div class="card-body text-dark flex">
                <p>Dessinateur :</p>
                <p class="card-text"><?php echo e($character->designer->name); ?></p>
            </div>
            <div class="card-body text-dark flex">
                <p>Bande dessinée :</p>
                <p class="card-text"><?php echo e($character->comics); ?></p>
            </div>
            <div class="card-body text-dark flex">
                <p>Année de création :</p>
                <p class="card-text"><?php echo e($character->creation_year); ?></p>
            </div>
            <div class="card-body text-dark flex">
              <form action="/deleteCharacter" method="POST">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($character->id); ?>">
                  <input type="submit" class="btn btn-danger" value="Supprimer">
              </form>
            </div>

            <div class="card-body text-dark flex">
            <a href="/updateCharacter/<?php echo e($character->id); ?>" class="btn btn-success">Mettre à jour</a>
          </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\comic\resources\views/character.blade.php ENDPATH**/ ?>