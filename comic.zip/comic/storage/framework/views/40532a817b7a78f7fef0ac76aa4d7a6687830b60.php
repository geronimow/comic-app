
<?php $__env->startSection('title', 'Ajout'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/add.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="title">Ajoute un personnage !</h1>
    <div>
        <form action="/addCharacter" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label for="title" class="col-sm-4 col-form-label">Nom</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="name" placeholder="Nom" value="Tintin">
                </div>
            </div>
            <div class="form-group row">
                <label for="designer" class="col-sm-4 col-form-label">Dessinateur</label>
                <div class="col-sm-8">
                    <select name="designer_id" id="">
                        <?php $__currentLoopData = $designers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($designer->id); ?>"><?php echo e($designer->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label for="publication_year" class="col-sm-4 col-form-label">Année de création</label>
                <div class="col-sm-8">
                    <input type="number" class="form-control" name="creation_year" placeholder="Année de création" value="1929">
                </div>
            </div>
            <div class="form-group row">
                <label for="comic" class="col-sm-4 col-form-label">Bande dessinée</label>
                <div class="col-sm-8">
                    <?php $__currentLoopData = $comics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="checkbox" name="comics" value="<?php echo e($comic->id); ?>">
                        <label for=""><?php echo e($comic->name); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div>
                <button type="submit" class="btn btn-primary">Ajouter</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\comic\resources\views/addCharacter.blade.php ENDPATH**/ ?>