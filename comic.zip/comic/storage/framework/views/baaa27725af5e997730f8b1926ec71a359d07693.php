
<?php $__env->startSection('title', 'Ajout'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/add.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="title">Ajoute un dessinateur !</h1>
    <div>
        <form action="/addDesigner" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label for="title" class="col-sm-4 col-form-label">Nom</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="name" placeholder="Nom" value="Hergé">
                </div>
            </div>

            <div class="form-group row">
                <label for="title" class="col-sm-4 col-form-label">Nationalité</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="nationality" placeholder="Nationalité" value="Belgique">
                </div>
            </div>

            <div class="form-group row">
                <label for="publication_year" class="col-sm-4 col-form-label">Année de naissance</label>
                <div class="col-sm-8">
                    <input type="number" class="form-control" name="birth_year" placeholder="Année de naissance" value="1907">
                </div>
            </div>
            <div>
                <button type="submit" class="btn btn-primary">Ajouter</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\comic\resources\views/addDesigner.blade.php ENDPATH**/ ?>