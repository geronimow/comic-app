
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/css/list.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Livres'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="title">Liste des personnages</h1>

<div class="list">
    <table class="table table-striped table-dark">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nom</th>
                <th scope="col">Dessinateur</th>
                <th scope="col">BD  </th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $characters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $character): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($character->id); ?></th>
                <td><a href="/character/<?php echo e($character->id); ?>"><?php echo e($character->name); ?></a></td>
                <td><a href="/designer/<?php echo e($character->designer->id); ?>"><?php echo e($character->designer->name); ?></a></td>
                <td>
                    <?php $__currentLoopData = $character->comics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($comic->name); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\comic\resources\views/list.blade.php ENDPATH**/ ?>