<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CharacterSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('characters')->insert([
            [
                'name' => 'Tintin',
                'designer_id' => 1,
                'creation_year' => 1929,

            ],
            [
                'name' => 'Boule',
                'designer_id' => 2,
                'creation_year' => 1959,
            ],
            [
                'name' => 'Astérix',
                'designer_id' => 3,
                'creation_year' => 2010,
            ],
        ]);
    }
}
