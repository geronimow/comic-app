<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class DesignerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('designers')->insert([
            [
                'name' => 'Hergé',
                'nationality' => 'Belgique',
                'birth_year' => '1907',

            ],
            [
                'name' => 'Jean Bastide',
                'nationality' => 'France',
                'birth_year' => '1982',
            ],
            [
                'name' => 'Albert Uderzo',
                'nationality' => 'France',
                'birth_year' => '1927',
            ],
        ]);
    }
}
