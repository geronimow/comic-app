<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class CharacterComicSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('character_comic')->insert([
            [
                'character_id' => 1,
                'comic_id' => 1,
            ],
            [
                'character_id' => 2,
                'comic_id' => 2,
            ],
            [
                'character_id' => 3,
                'comic_id' => 3,
            ],
        ]);
    }
}
