<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Character;
use App\Models\Designer;
use App\Models\Comic;

class ActionController extends Controller
{
    public function addCharacter(Request $request) {
        $character = new Character;
        $character->name = $request->name;
        $character->designer_id = $request->designer_id;
        $character->creation_year = $request->creation_year;
        $character->save();
        $character->comics()->attach($request->comics);
        return redirect('/list');
    }

    public function deleteCharacter(Request $request) {
        $character = Character::find($request->id);
        $character->comics()->detach();
        $character->delete();

        return redirect('/list');
    }

    public function deleteDesigner(Request $request) {
        $designer = Designer::find($request->id);
        $designer->delete();

        return redirect('/');
    }

    public function updateCharacter(Request $request) {
        $character = Character::findOrFail($request->id);
        $character->name = $request->name;
        $character->designer_id = $request->designer_id;
        $character->creation_year = $request->creation_year;
        $character->comics()->sync($request->comics);
        $character->save();
        return redirect('/list');
    }

    public function updateDesigner(Request $request) {
        $designer = Designer::findOrFail($request->id);
        $designer->name = $request->name;
        $designer->birth_year = $request->birth_year;
        $designer->nationality = $request->nationality;
        $designer->save();
        return redirect('/list');
    }

    public function addDesigner(Request $request) {
        $designer = new Designer;
        $designer->name = $request->name;
        $designer->nationality = $request->nationality;
        $designer->birth_year = $request->birth_year;
        $designer->save();
        return redirect('/list');
    }
}
