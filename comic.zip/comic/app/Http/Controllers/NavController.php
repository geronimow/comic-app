<?php

namespace App\Http\Controllers;
use App\Models\Designer;
use App\Models\Character;
use App\Models\Comic;

use Illuminate\Http\Request;

class NavController extends Controller
{
    public function home()
    {
        return view('home');
    }

    public function list()
    {
        $characters = Character::all();
        return view('list', ['characters' => $characters]);
    }

    public function character($id)
    {
        $character = Character::findOrFail($id);
        return view('character', ['character' => $character]);
    }

    public function designer($id)
    {
        $designer = Designer::findOrFail($id);
        return view('designer', ['designer' => $designer]);
    }

    public function updateCharacter($id)
    {
        $character = Character::findOrFail($id);
        $comics = Comic::all()->sortBy('name');
        $designers = Designer::all()->sortBy('name');
        return view('updateCharacter', ['character' => $character, 'designers' => $designers, 'comics' => $comics]);
    }

    public function updateDesigner($id)
    {
        $designer = Designer::findOrFail($id);
        $characters = Character::all()->sortBy('name');
        return view('updateDesigner', ['designer' => $designer, 'characters' => $characters]);
    }

    public function addCharacter()
    {
        $designers = Designer::all()->sortBy('name');
        $comics = Comic::all();
        return view('addCharacter', ['designers' => $designers, 'comics' => $comics]);
    }

    public function addDesigner()
    {
        $characters = Character::all()->sortBy('name');
        $comics = Comic::all();
        return view('addDesigner', ['characters' => $characters, 'comics' => $comics]);
    }
}
